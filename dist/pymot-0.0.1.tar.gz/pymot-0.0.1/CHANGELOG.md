# 0.0.1 (2022-08-06)

### Features

-   Perform multi object tracking and use a custom function for tracked objects
